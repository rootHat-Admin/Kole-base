<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *"); // Для AJAX

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');

// Валидация
$errors = [];

if (empty($name)) {
    $errors['name'] = 'Атыңызды толтырыңыз!';
} elseif (mb_strlen($name) < 2) {
    $errors['name'] = 'Атыңыздың ұзындығы 2 таңбадан кем болмауы керек!';
}

if (empty($email)) {
    $errors['email'] = 'Поштаны толтырыңыз!';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Пошта дұрыс емес!';
}

if (empty($message)) {
    $errors['message'] = 'Хабарламаны толтырыңыз!';
} elseif (mb_strlen($message) < 10) {
    $errors['message'] = 'Хабарлама өте қысқа (кемінде 10 таңба)!';
}

// Если есть ошибки
if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'errors' => $errors
    ]);
    exit;
}

// Успешная отправка (здесь можно добавить сохранение в БД или отправку email)
echo json_encode([
    'success' => true,
    'message' => 'Хабарлама сәтті жіберілді!'
]);
?>