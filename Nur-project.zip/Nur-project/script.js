// Плавная прокрутка для навигации
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        document.querySelector(targetId).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Валидация формы
document.querySelector('form').addEventListener('submit', (e) => {
    const name = document.querySelector('input[name="name"]').value.trim();
    const email = document.querySelector('input[name="email"]').value.trim();
    const message = document.querySelector('textarea[name="message"]').value.trim();

    // Проверка имени (минимум 2 символа)
    if (name.length < 2) {
        alert('Атыңызды толтырыңыз (кемінде 2 таңба)!');
        e.preventDefault();
        return;
    }

    // Проверка email (простая валидация)
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        alert('Электрондық пошта дұрыс емес!');
        e.preventDefault();
        return;
    }

    // Проверка сообщения (минимум 10 символов)
    if (message.length < 10) {
        alert('Хабарлама өте қысқа (кемінде 10 таңба)!');
        e.preventDefault();
        return;
    }
});