<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <title>Пайдаланушы мәліметтері</title>
</head>
<body>
    <h2>Мәліметтерді енгізіңіз</h2>
    <form action="" method="post">
        <div>
            <label for="user">Есімі:</label><br>
            <input type="text" id="user" name="username" required>
        </div>
        <br>
        <div>
            <label for="years">Жасы:</label><br>
            <input type="number" id="years" name="userage" required>
        </div>
        <br>
        <input type="submit" value="Жөнелту">
    </form>

    <?php
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $username = htmlspecialchars($_POST["username"]);
            $userage = (int)$_POST["userage"];

            echo "<hr>";
            echo "<h3>Кіріс нәтижелері</h3>";
            echo "<p><strong>Есімі:</strong> $username</p>";
            echo "<p><strong>Жасы:</strong> $userage</p>";
        }
    ?>
</body>
</html>