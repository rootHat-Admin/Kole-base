<?php
// Проверка, была ли отправлена форма
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем данные из формы
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Формирование текста сообщения
    $subject = "Пікір қалдыру от $name";
    $messageContent = "Аты: $name\nEmail: $email\nПікір:\n$message";

    // Установим заголовки для email
    $headers = "From: $email" . "\r\n" .
               "Reply-To: $email" . "\r\n" .
               "Content-Type: text/plain; charset=UTF-8";

    // Отправка email (замените email@example.com на свой адрес)
    $to = "email@example.com"; // сюда ваш email
    if (mail($to, $subject, $messageContent, $headers)) {
        echo "<p>Пікіріңіз сәтті жіберілді!</p>";
    } else {
        echo "<p>Кешіріңіз, пікірді жіберу мүмкін болмады. Қайтадан көріп шығыңыз.</p>";
    }
} else {
    echo "<p>Форма дұрыс толтырылмады!</p>";
}
?>
