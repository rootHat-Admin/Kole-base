const courseGrid = document.getElementById("courseGrid");
const modal = document.getElementById("modal");
const modalClose = document.getElementById("modalClose");
const modalCourseTitle = document.getElementById("modalCourseTitle");
const enrollForm = document.getElementById("enrollForm");

const courses = [
  {title: "Бағдарламалау негіздері", description: "Бұл курс бағдарламалаудың алғашқы қадамдарын үйретеді. Python және JavaScript тілдерін меңгересіз."},
  {title: "Веб-әзірлеу", description: "HTML, CSS және JavaScript арқылы веб-сайт жасау дағдыларын дамытасыз."},
  {title: "Деректер құрылымы мен алгоритмдер", description: "Деректер құрылымдарын түсініп, тиімді алгоритмдерді жазуды үйренесіз."},
  {title: "Машиналық оқыту", description: "Нейрондық желілер мен жасанды интеллект негіздерімен танысасыз."},
  {title: "Мобильді қосымшалар әзірлеу", description: "Android және iOS платформаларына қосымша жасау әдістері."},
  {title: "Графикалық дизайн", description: "Adobe Photoshop пен Illustrator бағдарламаларында жұмыс істеу дағдылары."},
  {title: "Жобаларды басқару", description: "Командада тиімді жұмыс істеу және жобаларды басқару негіздері."},
  {title: "Киберқауіпсіздік", description: "Интернет қауіпсіздігін қамтамасыз ету және хакерлік шабуылдардан қорғану әдістері."},
  {title: "Тілді дамыту курсы", description: "Қазақ тілін жетілдіру, әдебиет және жазу дағдыларын дамыту."},
  {title: "Фотография негіздері", description: "Фотоаппаратпен жұмыс істеу, жарық пен кадрлау әдістері."},
  {title: "Экономика негіздері", description: "Нарықтық экономика және бизнес негіздері туралы түсінік."},
  {title: "Маркетинг және жарнама", description: "Нарықтық зерттеу және тиімді жарнама жасау стратегиялары."},
  {title: "Видео монтаж", description: "Adobe Premiere және After Effects көмегімен видеоны өңдеу негіздері."},
  {title: "Әлеуметтік медианы басқару", description: "Instagram, Facebook, TikTok платформаларында бренд жасау жолдары."},
  {title: "Дене тәрбиесі және спорт", description: "Денсаулықты нығайту және спорттық жаттығулар."},
  {title: "Мәдениет және тарих", description: "Қазақ халқының тарихы мен мәдениеті туралы терең білім."},
  {title: "Бизнес негіздері", description: "Жеке кәсіпкерлік ашу және басқару дағдылары."},
  {title: "Креативті жазу", description: "Шығармашылық жазу және идеяларды дамыту әдістері."},
  {title: "Английский для начинающих", description: "Ағылшын тілінің негізгі грамматикасы мен сөздік қоры."},
  {title: "Қоршаған орта және экология", description: "Экологиялық мәселелер және табиғатты қорғау жолдары."}
];

courses.forEach((course, i) => {
  const card = document.createElement("div");
  card.className = "course-card";
  card.innerHTML = `
    <h3>Курс ${i + 1}: ${course.title}</h3>
    <p>${course.description}</p>
    <button class="enroll-btn" data-index="${i}">Жазылу</button>
  `;
  courseGrid.appendChild(card);
});

// Открыть модалку с нужным курсом
courseGrid.addEventListener("click", e => {
  if (e.target.classList.contains("enroll-btn")) {
    const idx = e.target.dataset.index;
    modalCourseTitle.textContent = `Курсқа жазылу: ${courses[idx].title}`;
    modal.style.display = "flex";
  }
});

// Закрыть модалку крестиком
modalClose.onclick = () => {
  modal.style.display = "none";
  enrollForm.reset();
};

// Закрыть при клике вне окна
window.onclick = (e) => {
  if (e.target == modal) {
    modal.style.display = "none";
    enrollForm.reset();
  }
};

// Отправка формы
enrollForm.addEventListener("submit", e => {
  e.preventDefault();

  const name = enrollForm.name.value.trim();
  const email = enrollForm.email.value.trim();
  const phone = enrollForm.phone.value.trim();

  if (!name || !email || !phone) {
    alert("Барлық міндетті өрістерді толтырыңыз!");
    return;
  }

  alert(`Рахмет, ${name}! Сіздің өтінішіңіз қабылданды.`);
  modal.style.display = "none";
  enrollForm.reset();
});