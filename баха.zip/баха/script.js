const reviewForm = document.getElementById('reviewForm');
const reviewList = document.getElementById('reviewList');

reviewForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('reviewName').value.trim();
    const text = document.getElementById('reviewText').value.trim();

    if (text.length < 10) {
        alert('Өтінеміз, пікіріңізді толық әрі нақты жазыңыз.');
        return;
    }

    if (name.length === 0) {
        alert('Өтінеміз, атыңызды енгізіңіз.');
        return;
    }

    // Жұлдызшаларды алу
    const stars = reviewForm.elements['stars'];
    let rating = 0;
    for (const star of stars) {
        if (star.checked) {
            rating = star.value;
            break;
        }
    }
    if (rating === 0) {
        alert('Өтінеміз, жұлдызша санын таңдаңыз.');
        return;
    }

    // Жұлдызшаларды көрсету
    const starsDisplay = '★'.repeat(rating) + '☆'.repeat(5 - rating);

    const newReview = document.createElement('div');
    newReview.classList.add('review');
    newReview.innerHTML = `
        <img src="https://randomuser.me/api/portraits/lego/1.jpg" alt="Клиент" />
        <div class="review-content">
          <h4>${name}</h4>
          <p>${text}</p>
          <div class="review-stars">${starsDisplay}</div>
        </div>
    `;

    reviewList.prepend(newReview);
    reviewForm.reset();
});
 document.getElementById('bookingForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const name = this.name.value.trim();
    const email = this.email.value.trim();
    const tour = this.tour.value;

    if (name.length < 2) {
      alert('Атыңызды дұрыс енгізіңіз');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      alert('Дұрыс email енгізіңіз');
      return;
    }

    if (!tour) {
      alert('Тур таңдаңыз');
      return;
    }

    // Здесь можно добавить отправку данных на сервер через fetch/AJAX
    // Пока просто покажем сообщение об успехе:
    document.getElementById('formMessage').textContent = 'Тур сәтті брондалды! Қатысқаныңыз үшін рақмет!';

    this.reset();
});

const openLink = document.getElementById('openBookingLink'); // ссылка <a>
const openBtn = document.getElementById('openBooking');      // кнопка <button>
const modal = document.getElementById('modalOverlay');
const closeBtn = document.getElementById('closeModal');
const bookingForm = document.getElementById('bookingForm');
const formMessage = document.getElementById('formMessage');

function openModal(e) {
  e.preventDefault(); // чтобы ссылка не прыгала
  modal.classList.remove('hidden');
  formMessage.textContent = '';
}

openLink.addEventListener('click', openModal);
openBtn.addEventListener('click', openModal);

closeBtn.addEventListener('click', () => {
  modal.classList.add('hidden');
  bookingForm.reset();
});

modal.addEventListener('click', (e) => {
  if (e.target === modal) {
    modal.classList.add('hidden');
    bookingForm.reset();
  }
});

bookingForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const name = bookingForm.name.value.trim();
  const email = bookingForm.email.value.trim();
  const tour = bookingForm.tour.value;

  if (!name || !email || !tour) {
    formMessage.style.color = 'red';
    formMessage.textContent = 'Барлық өрістерді толтырыңыз.';
    return;
  }

  formMessage.style.color = '#28a745';
  formMessage.textContent = `Рахмет, ${name}! Сіздің өтінішіңіз қабылданды. Біз сізбен жақын арада байланысамыз.`;

  bookingForm.reset();

  setTimeout(() => {
    modal.classList.add('hidden');
    formMessage.textContent = '';
  }, 4000);
});

const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const wrapper = document.querySelector('.news-wrapper');

  const itemWidth = 295; // ширина блока + margin-right
  const totalItems = 20;
  const visibleCount = 3;

  let currentIndex = 0;
  const maxIndex = totalItems - visibleCount;

  prevBtn.addEventListener('click', () => {
    currentIndex = Math.max(0, currentIndex - 1);
    wrapper.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
  });

  nextBtn.addEventListener('click', () => {
    currentIndex = Math.min(maxIndex, currentIndex + 1);
    wrapper.style.transform = `translateX(${-currentIndex * itemWidth}px)`;
  });