
const form = document.getElementById('calculator-form');
const resultElement = document.getElementById('result');

form.addEventListener('submit', (e) => {
    e.preventDefault();

    const lessonType = document.getElementById('lesson-type').value;
    const lessonDuration = parseInt(document.getElementById('lesson-duration').value);
    const teacherLevel = document.getElementById('teacher-level').value;

    let cost = 0;

    switch (lessonType) {
        case 'group':
            cost = lessonDuration * 10000;
            break;
        case 'individual':
            cost = lessonDuration * 15000;
            break;
    }

    switch (teacherLevel) {
        case 'junior':
            cost *= 0.8;
            break;
        case 'middle':
            cost *= 1;
            break;
        case 'senior':
            cost *= 1.2;
            break;
    }

    resultElement.textContent = `The cost of the lesson is ${cost} tenge`;
});